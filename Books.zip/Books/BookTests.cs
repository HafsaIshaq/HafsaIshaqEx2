﻿using Xunit;

namespace UnitTests
{
    public class Book_Should
    {
        [Fact]
        public void Create_New_Book_With_Valid_Data()
        {
            // example from the workbook done in class:
            // string title = "Sample Book";
            string title = "Hannibal Rising"; // ive used hannibal rising since i love the hannibal lecter movie and show series and ive read all the hannibal novels...
            string author = "Thomas Harris";
            string isbn = "978-0-099-47867-4";
            int copies = 5;

            // workbook example:
            // var book = new Book(title, author, isbn, copies);
            var book = new BookSystem.Book(title, author, isbn, copies);

            // workbook example:
            // Assert.Equal(title, book.Title);
            Assert.Equal(title, book.Title);
            Assert.Equal(author, book.Author);
            Assert.Equal(isbn, book.ISBN);
            Assert.Equal(copies, book.Copies);
        }

        [Fact]
        public void Throw_Exception_With_Invalid_Data()
        {
            // example: string title = null;
            string title = null;
            string author = "Thomas Harris";
            string isbn = "978-0-099-47867-4";
            int copies = 5;

            // example: Assert.Throws<ArgumentException>(() => new Book(title, author, isbn, copies));
            Assert.Throws<ArgumentException>(() => new BookSystem.Book(title, author, isbn, copies));
        }
    }
}
