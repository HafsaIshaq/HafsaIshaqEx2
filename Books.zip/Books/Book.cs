﻿// Author: Hafsa Ishaq

using System;

namespace BookSystem
{
    public class Book
    {
        public string Title { get; private set; }
        public string Author { get; private set; }
        public string ISBN { get; private set; }
        public int Copies { get; private set; }

        public Book(string title, string author, string isbn, int copies = 1)
        {
            if (string.IsNullOrWhiteSpace(title))
                throw new ArgumentException("Title is required.");

            if (string.IsNullOrWhiteSpace(author))
                throw new ArgumentException("Author is required.");

            if (string.IsNullOrWhiteSpace(isbn))
                throw new ArgumentException("ISBN is required.");

            if (copies <= 0)
                throw new ArgumentException("Copies must be greater than 0.");

            Title = title.Trim();
            Author = author.Trim();
            ISBN = isbn.Trim();
            Copies = copies;
        }

        public override string ToString()
        {
            return $"{Title}, {Author}, {ISBN}, {Copies}";
        }
    }
}